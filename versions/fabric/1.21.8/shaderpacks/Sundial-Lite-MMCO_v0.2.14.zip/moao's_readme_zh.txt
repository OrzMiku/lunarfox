Sundial-lite项目原地址：https://github.com/GeForceLegend/Sundial-Lite
MMCO改版可从这里获得：https://github.com/MoAoXnX/Sundial-Lite-MMCO/releases
以自己审美来的色彩调整，以及一些代码的简单修改。