Sundial-lite项目原地址：https://github.com/GeForceLegend/Sundial-Lite
MMCO改版可从这里获得：https://github.com/MoAoXnX/Sundial-Lite-MMCO/releases
修改了日出前大气亮度，最低亮度，以自己审美来的色彩调整，以及一些参数的简单调整。